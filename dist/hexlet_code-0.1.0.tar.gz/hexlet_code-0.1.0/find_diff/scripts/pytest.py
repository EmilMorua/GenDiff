from find_diff.tests import tests_gendiff_json


def main():
    return tests_gendiff_json


if __name__ == '__main__':
    main()
