from comparison import compare_dicts
from formaters.formater_json import get_diff_json
from formaters.formater_plain import get_diff_plain
from formaters.formater_stylish import get_diff_stylish
from unpack_files import unpack_file


def generate_diff(file_path1: str, file_path2: str, format_name: str = 'stylish') -> str:
    """
    Generate a string representation of the difference between two files.

    Args:
        file_path1: A string representing the path to the first file.
        file_path2: A string representing the path to the second file.

    Returns:
        A string representation of the difference between the two files.
    """

    dict1, dict2 = unpack_file(file_path1), unpack_file(file_path2)
    diff_dict = compare_dicts(dict1, dict2)

    if format_name == 'json':
        return get_diff_json(diff_dict)
    elif format_name == 'plain':
        return get_diff_plain(diff_dict)
    elif format_name == 'stylish':
        return get_diff_stylish(diff_dict)


# json
path1 = 'find_diff/tests/fixtures/file1.json'
path2 = 'find_diff/tests/fixtures/file2.json'

path3 = 'find_diff/tests/fixtures/file3.json'
path4 = 'find_diff/tests/fixtures/file4.json'
# yaml
path5 = 'find_diff/tests/fixtures/file1.yaml'
path6 = 'find_diff/tests/fixtures/file2.yaml'

path7 = 'find_diff/tests/fixtures/file3.yaml'
path8 = 'find_diff/tests/fixtures/file4.yaml'


print(generate_diff(path7, path8, 'json'))
