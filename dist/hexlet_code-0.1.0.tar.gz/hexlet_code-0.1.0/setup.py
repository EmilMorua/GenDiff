# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['find_diff',
 'find_diff.formaters',
 'find_diff.scripts',
 'find_diff.tests',
 'find_diff.tests.fixtures']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=4.0.0,<5.0.0', 'pytest>=7.2.2,<8.0.0']

entry_points = \
{'console_scripts': ['gendiff = find_diff.scripts.entrance_point:main',
                     'pytest = find_diff.scripts.pytest:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/EmilMorua/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/EmilMorua/python-project-50/actions)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/ad6ffcad69d43ac046c5/test_coverage)](https://codeclimate.com/github/EmilMorua/python-project-50/test_coverage)\n[![Tests and Linter](https://github.com/EmilMorua/python-project-50/actions/workflows/test_and_linter.yml/badge.svg)](https://github.com/EmilMorua/python-project-50/actions/workflows/test_and_linter.yml)',
    'author': 'Emil Murzin',
    'author_email': 'emil.morua@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10.6,<4.0.0',
}


setup(**setup_kwargs)
