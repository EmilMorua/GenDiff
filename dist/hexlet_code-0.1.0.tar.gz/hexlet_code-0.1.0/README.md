### Hexlet tests and linter status:
[![Actions Status](https://github.com/EmilMorua/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/EmilMorua/python-project-50/actions)
[![Test Coverage](https://api.codeclimate.com/v1/badges/ad6ffcad69d43ac046c5/test_coverage)](https://codeclimate.com/github/EmilMorua/python-project-50/test_coverage)
[![Tests and Linter](https://github.com/EmilMorua/python-project-50/actions/workflows/test_and_linter.yml/badge.svg)](https://github.com/EmilMorua/python-project-50/actions/workflows/test_and_linter.yml)