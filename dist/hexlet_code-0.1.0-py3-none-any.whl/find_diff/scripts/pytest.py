from find_diff.tests import tests


def main():
    return tests


if __name__ == '__main__':
    main()
